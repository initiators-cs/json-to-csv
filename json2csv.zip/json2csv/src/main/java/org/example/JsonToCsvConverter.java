package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class JsonToCsvConverter {

    private static String[] CSV_HEADERS;

    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java JsonToCsvConverter <jsonFilePath> <csvOutputPath>");
            return;
        }
        String jsonFilePath = args[0];
        String csvOutputPath = args[1];
        String configPath = "src/main/resources/config.properties"; // Assuming the config file path

        loadConfig(configPath);

        try {
            convertJsonToCsv(jsonFilePath, csvOutputPath);
            System.out.println("CSV file has been generated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void loadConfig(String configPath) {
        Properties prop = new Properties();
        try (FileReader reader = new FileReader(configPath)) {
            prop.load(reader);
            String headers = prop.getProperty("csv.headers");
            if (headers != null) {
                CSV_HEADERS = headers.split("\\|");
            } else {
                throw new RuntimeException("CSV headers are not specified in the config.properties file.");
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to load configuration from " + configPath, e);
        }
    }

    private static void convertJsonToCsv(String jsonFilePath, String csvOutputPath) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        System.out.println("Attempting to open JSON file at path: " + jsonFilePath);

        try (FileReader jsonReader = new FileReader(jsonFilePath)) {
            JsonNode rootNode = mapper.readTree(jsonReader);

            List<String> csvLines = new ArrayList<>();
            String headerLine = String.join(",", CSV_HEADERS);
            csvLines.add(headerLine);

            if (rootNode.isArray()) {
                for (JsonNode element : rootNode) {
                    processJsonElement(element, csvLines);
                }
            }

            try (PrintWriter out = new PrintWriter(csvOutputPath)) {
                csvLines.forEach(out::println);
            }
        }
    }

    private static void processJsonElement(JsonNode element, List<String> csvLines) {
        List<String> baseValues = extractValuesFromJson(element, 0, 19);  // Base fields
        JsonNode ticketLines = element.get("ShippingTicketLines");

        if (ticketLines != null && ticketLines.isArray()) {
            for (JsonNode line : ticketLines) {
                List<String> lineValues = new ArrayList<>(baseValues);
                lineValues.addAll(extractValuesFromJson(line, 19, CSV_HEADERS.length));
                csvLines.add(String.join(",", lineValues));
            }
        } else {
            List<String> lineValues = new ArrayList<>(baseValues);
            for (int i = 19; i < CSV_HEADERS.length; i++) {
                lineValues.add(""); // Add empty string for each ticket line field
            }
            csvLines.add(String.join(",", lineValues));
        }
    }

    /*private static List<String> extractValuesFromJson(JsonNode jsonNode, int start, int end) {
        List<String> values = new ArrayList<>();
        for (int i = start; i < end; i++) {
            String field = CSV_HEADERS[i].contains(".") ? CSV_HEADERS[i].substring(CSV_HEADERS[i].indexOf(".") + 1) : CSV_HEADERS[i];
            JsonNode valueNode = jsonNode.get(field);
            values.add(valueNode != null && !valueNode.isNull() ? valueNode.asText() : "");
        }
        return values;
    }*/
    private static List<String> extractValuesFromJson(JsonNode jsonNode, int start, int end) {
        List<String> values = new ArrayList<>();
        for (int i = start; i < end; i++) {
            String field = CSV_HEADERS[i].contains(".") ? CSV_HEADERS[i].substring(CSV_HEADERS[i].indexOf(".") + 1) : CSV_HEADERS[i];
            JsonNode valueNode = jsonNode.get(field);
            String textValue = valueNode != null && !valueNode.isNull() ? valueNode.asText() : "";

            // Check if the value contains a comma, newline, or double quotes and wrap it in double quotes if it does
            if (textValue.contains(",") || textValue.contains("\n") || textValue.contains("\"")) {
                textValue = "\"" + textValue.replace("\"", "\"\"") + "\""; // Replace existing double quotes with two double quotes
            }

            values.add(textValue);
        }
        return values;
    }

}
