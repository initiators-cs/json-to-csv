package org.example;

import com.opencsv.CSVWriter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.*;
import java.util.*;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String jsonFilePath = "st-469.json";
        String csvFilePath = "st-469.csv";

        try (FileReader reader = new FileReader(jsonFilePath)) {
            JSONTokener tokener = new JSONTokener(reader);
            JSONArray jsonArray = new JSONArray(tokener);

            // Load properties file
            Properties prop = new Properties();
            InputStream input = Main.class.getClassLoader().getResourceAsStream("config.properties");
            prop.load(input);

            // Get headers from properties file
            String headersProp = prop.getProperty("headers");
            List<String> headers = new ArrayList<>(Arrays.asList(headersProp.split("\\|"))); // Split by pipe symbol

            try (CSVWriter writer = new CSVWriter(new FileWriter(csvFilePath), '|', CSVWriter.NO_ESCAPE_CHARACTER, CSVWriter.DEFAULT_ESCAPE_CHARACTER, CSVWriter.DEFAULT_LINE_END
            )) {
                // Write header to the CSV file
                writer.writeNext(headers.toArray(new String[0]));

                // Write data to the CSV file
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    List<String> csvRow = new ArrayList<>();

                    for (String header : headers) {
                        String[] path = header.split("\\."); // Split by dot symbol
                        JSONObject currentObject = jsonObject;
                        for (int j = 0; j < path.length - 1; j++) {
                            if (currentObject.has(path[j])) {
                                if (currentObject.get(path[j]) instanceof JSONObject) {
                                    currentObject = currentObject.getJSONObject(path[j]);
                                } else if (currentObject.get(path[j]) instanceof JSONArray) {
                                    JSONArray array = currentObject.getJSONArray(path[j]);
                                    // Assuming that we're looking for a JSON object within the array that has a specific type
                                    for (int k = 0; k < array.length(); k++) {
                                        if (array.getJSONObject(k).has(path[j + 1])) {
                                            currentObject = array.getJSONObject(k);
                                            populateData (writer, csvRow, path, currentObject);
                                        }
                                    }
                                }
                            }
                        }

                        // Handle the final field in the path
                        /*String finalField = path[path.length - 1];
                        if (currentObject.has(finalField)) {
                            Object value = currentObject.get(finalField);
                            if (value instanceof String) {
                                csvRow.add(currentObject.getString(finalField));
                            } else if (value instanceof Double) {
                                csvRow.add(String.valueOf(currentObject.getDouble(finalField)));
                            } else if (value instanceof Boolean) {
                                csvRow.add(String.valueOf(currentObject.getBoolean(finalField)));
                            } else if (value instanceof JSONArray) {
                                csvRow.add(currentObject.getJSONArray(finalField).toString());
                            } else {
                                // For any other types, add the value as a string
                                csvRow.add(value.toString());
                            }
                        } else {
                            // The final field doesn't exist; add an empty string
                            csvRow.add("");
                        }*/
                    }

                    // Write the CSV row
                    //writer.writeNext(csvRow.toArray(new String[0]));
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

        public static void populateData (CSVWriter writer, List < String > csvRow, String[]path, JSONObject
        currentObject){
            String finalField = path[path.length - 1];
            if (currentObject.has(finalField)) {
                Object value = currentObject.get(finalField);
                if (value instanceof String) {
                    csvRow.add(currentObject.getString(finalField));
                } else if (value instanceof Double) {
                    csvRow.add(String.valueOf(currentObject.getDouble(finalField)));
                } else if (value instanceof Boolean) {
                    csvRow.add(String.valueOf(currentObject.getBoolean(finalField)));
                } else if (value instanceof JSONArray) {
                    csvRow.add(currentObject.getJSONArray(finalField).toString());
                } else {
                    // For any other types, add the value as a string
                    csvRow.add(value.toString());
                }
            } else {
                // The final field doesn't exist; add an empty string
                csvRow.add("");
            }
            writer.writeNext(csvRow.toArray(new String[0]));
        }

    }
